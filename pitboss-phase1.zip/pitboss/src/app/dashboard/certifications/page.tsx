'use client'

import { useEffect, useState } from 'react'

type Cert = {
  id: string
  status: string
  score: number | null
  issued_at: string | null
  expires_at: string | null
  members: { username: string }
  certification_types: { name: string; passing_score: number }
}

export default function CertificationsPage() {
  const [certs, setCerts] = useState<Cert[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    fetch('/api/certifications')
      .then(r => r.json())
      .then(data => { setCerts(data); setLoading(false) })
  }, [])

  const filtered = filter === 'all' ? certs : certs.filter(c => c.status === filter)

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-black text-white uppercase tracking-tight">Certifications</h1>
          <p className="text-zinc-500 text-sm mt-1">All member certification records</p>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 mb-6">
        {['all', 'passed', 'failed', 'pending', 'expired'].map(s => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`text-xs px-3 py-1.5 rounded-full uppercase tracking-wider font-medium transition-colors ${
              filter === s
                ? 'bg-red-600 text-white'
                : 'bg-zinc-800 text-zinc-400 hover:text-white'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-zinc-600">Loading...</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-zinc-600">No certifications found.</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-500 text-xs uppercase tracking-wider">
                <th className="text-left p-4">Member</th>
                <th className="text-left p-4">Certification</th>
                <th className="text-left p-4">Status</th>
                <th className="text-left p-4">Score</th>
                <th className="text-left p-4">Expires</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(cert => (
                <tr key={cert.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors">
                  <td className="p-4 text-white font-medium">{cert.members?.username}</td>
                  <td className="p-4 text-zinc-400">{cert.certification_types?.name}</td>
                  <td className="p-4">
                    <StatusBadge status={cert.status} />
                  </td>
                  <td className="p-4 text-zinc-400">
                    {cert.score !== null ? (
                      <span className={cert.score >= (cert.certification_types?.passing_score ?? 80) ? 'text-green-400' : 'text-red-400'}>
                        {cert.score}%
                      </span>
                    ) : '—'}
                  </td>
                  <td className="p-4 text-zinc-400">
                    {cert.expires_at ? new Date(cert.expires_at).toLocaleDateString() : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    passed: 'bg-green-950 text-green-400 border-green-900',
    failed: 'bg-red-950 text-red-400 border-red-900',
    pending: 'bg-zinc-800 text-zinc-400 border-zinc-700',
    in_progress: 'bg-yellow-950 text-yellow-400 border-yellow-900',
    expired: 'bg-orange-950 text-orange-400 border-orange-900',
  }
  return (
    <span className={`text-xs px-2 py-0.5 rounded border font-medium uppercase tracking-wide ${styles[status] ?? styles.pending}`}>
      {status.replace('_', ' ')}
    </span>
  )
}
