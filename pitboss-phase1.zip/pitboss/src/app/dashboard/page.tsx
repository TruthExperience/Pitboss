import { auth } from '@/lib/auth'
import { supabase } from '@/lib/supabase'

export default async function DashboardPage() {
  const session = await auth()

  // Fetch summary stats
  const [{ count: memberCount }, { count: certCount }, { data: recentCerts }] =
    await Promise.all([
      supabase.from('members').select('*', { count: 'exact', head: true }),
      supabase.from('certifications').select('*', { count: 'exact', head: true }).eq('status', 'passed'),
      supabase
        .from('certifications')
        .select('*, members(username), certification_types(name)')
        .order('created_at', { ascending: false })
        .limit(5),
    ])

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-black text-white uppercase tracking-tight">
          Welcome back{session?.user?.name ? `, ${session.user.name}` : ''}
        </h1>
        <p className="text-zinc-500 text-sm mt-1">TRL & WSC Certification Overview</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
        <StatCard label="Total Members" value={memberCount ?? 0} />
        <StatCard label="Certifications Passed" value={certCount ?? 0} accent />
        <StatCard label="Active Leagues" value={2} />
      </div>

      {/* Recent certifications */}
      <div>
        <h2 className="text-xs text-zinc-500 uppercase tracking-widest mb-4">
          Recent Certifications
        </h2>
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden">
          {recentCerts && recentCerts.length > 0 ? (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-500 text-xs uppercase tracking-wider">
                  <th className="text-left p-4">Member</th>
                  <th className="text-left p-4">Certification</th>
                  <th className="text-left p-4">Status</th>
                  <th className="text-left p-4">Score</th>
                </tr>
              </thead>
              <tbody>
                {recentCerts.map((cert: any) => (
                  <tr key={cert.id} className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors">
                    <td className="p-4 text-white font-medium">{cert.members?.username}</td>
                    <td className="p-4 text-zinc-400">{cert.certification_types?.name}</td>
                    <td className="p-4">
                      <StatusBadge status={cert.status} />
                    </td>
                    <td className="p-4 text-zinc-400">{cert.score ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="p-8 text-center text-zinc-600">No certifications yet.</div>
          )}
        </div>
      </div>
    </div>
  )
}

function StatCard({ label, value, accent }: { label: string; value: number; accent?: boolean }) {
  return (
    <div className={`bg-zinc-900 border rounded-xl p-6 ${accent ? 'border-red-900' : 'border-zinc-800'}`}>
      <div className={`text-3xl font-black mb-1 ${accent ? 'text-red-500' : 'text-white'}`}>
        {value}
      </div>
      <div className="text-xs text-zinc-500 uppercase tracking-wider">{label}</div>
    </div>
  )
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    passed: 'bg-green-950 text-green-400 border-green-900',
    failed: 'bg-red-950 text-red-400 border-red-900',
    pending: 'bg-zinc-800 text-zinc-400 border-zinc-700',
    in_progress: 'bg-yellow-950 text-yellow-400 border-yellow-900',
    expired: 'bg-orange-950 text-orange-400 border-orange-900',
  }
  return (
    <span className={`text-xs px-2 py-0.5 rounded border font-medium uppercase tracking-wide ${styles[status] ?? styles.pending}`}>
      {status.replace('_', ' ')}
    </span>
  )
}
