import { auth } from '@/lib/auth'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { signOut } from '@/lib/auth'

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await auth()
  if (!session?.user) redirect('/auth/login')

  return (
    <div className="flex min-h-screen bg-zinc-950">
      {/* Sidebar */}
      <aside className="w-64 bg-zinc-900 border-r border-zinc-800 flex flex-col">
        {/* Logo */}
        <div className="p-6 border-b border-zinc-800">
          <div className="flex items-center gap-2">
            <div className="w-2 h-7 bg-red-600" />
            <span className="text-xl font-black tracking-tight text-white uppercase">
              PitBoss
            </span>
          </div>
          <p className="text-zinc-500 text-xs mt-1 tracking-widest uppercase">
            Certification Portal
          </p>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-4 space-y-1">
          <NavLink href="/dashboard" label="Dashboard" icon="⬛" />
          <NavLink href="/dashboard/certifications" label="Certifications" icon="🏁" />
          <NavLink href="/dashboard/members" label="Members" icon="👥" />
          <NavLink href="/dashboard/profile" label="My Profile" icon="👤" />
        </nav>

        {/* User / Signout */}
        <div className="p-4 border-t border-zinc-800">
          <div className="text-xs text-zinc-500 mb-2 truncate">{session.user.email}</div>
          <form action={async () => { 'use server'; await signOut({ redirectTo: '/auth/login' }) }}>
            <button
              type="submit"
              className="w-full text-left text-sm text-zinc-400 hover:text-red-500 transition-colors"
            >
              Sign out →
            </button>
          </form>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 overflow-auto">
        {children}
      </main>
    </div>
  )
}

function NavLink({ href, label, icon }: { href: string; label: string; icon: string }) {
  return (
    <Link
      href={href}
      className="flex items-center gap-3 px-3 py-2 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors text-sm"
    >
      <span>{icon}</span>
      <span>{label}</span>
    </Link>
  )
}
