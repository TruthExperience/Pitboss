import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@/lib/auth'
import { supabase } from '@/lib/supabase'

export async function GET(req: NextRequest) {
  const session = await auth()
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const memberId = searchParams.get('member_id')

  let query = supabase
    .from('certifications')
    .select(`
      *,
      certification_types (name, description, passing_score),
      members (username, email)
    `)

  if (memberId) query = query.eq('member_id', memberId)

  const { data, error } = await query.order('created_at', { ascending: false })

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

export async function POST(req: NextRequest) {
  const session = await auth()
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const body = await req.json()
  const { member_id, certification_type_id, score, notes } = body

  const passed = score >= 80
  const { data, error } = await supabase
    .from('certifications')
    .insert({
      member_id,
      certification_type_id,
      score,
      notes,
      status: passed ? 'passed' : 'failed',
      issued_at: passed ? new Date().toISOString() : null,
      expires_at: passed
        ? new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
        : null,
    })
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data, { status: 201 })
}
